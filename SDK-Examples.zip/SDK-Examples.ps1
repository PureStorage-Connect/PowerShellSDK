﻿#
# Quick Start Guide for Pure Storage PowerShell SDK
# Step-by-step example script
# Author: 
#    barkz@purestorage.com
# Description: 
#    Each of the below Sections corresponds to a section in the Quick Start Guide.
#    Validated with SDK 1.0.15.0
#

#
# Getting Started
#
Get-Module -ListAvailable
$env:PSModulePath
Get-Command -Module PureStoragePowerShellSDK
(Get-Command -Module PureStoragePowerShellSDK).Count
Update-Help -Module PureStoragePowerShellSDK # Requires Run as Administrator
Get-Help New-PfaArray
Get-Help New-PfaArray -Full
Get-Help New-PfaArray -Detailed
Get-Help New-PfaArray -Examples

#
# Connecting to the FlashArray
#
$Creds = Get-Credential
$FlashArray = New-PfaArray -EndPoint <IP/DNS> -Credentials $Creds -IgnoreCertificateError
Get-PfaControllers -Array $FlashArray 
$Controllers = Get-PfaControllers –Array $FlashArray
$Controllers

#
# Working with Volumes
#
New-PfaVolume –Array $FlashArray –VolumeName 'TEST-VOL' –Unit 'TB' –Size 2
ForEach ($i in 2..10) { New-PfaVolume –Array $FlashArray –VolumeName “TEST-VOL$i” –Unit TB –Size 2 } 
Get-PfaVolume –Array $FlashArray –Name ‘TEST-VOL’ | Format-Table –Autosize
Rename-PfaVolumeOrSnapshot –Array $FlashArray –NewName ‘TEST-VOL1’ –Name ‘TEST-VOL’

# 
# Volume and Host Connections
#
$wwn=@('10:00:00:00:00:00:11:11','10:00:00:00:00:00:12:12')
New-PfaHost –Array $FlashArray –Name ‘TEST-HOST1’ –WwnList $wwn
New-PfaHostGroup -Array $FlashArray -Hosts 'TEST-HOST1' -Name 'TEST-HOSTGROUP'
New-PfaHostVolumeConnection -Array $FlashArray -VolumeName 'TEST-VOL1' -HostName 'TEST-HOST1'
New-PfaHostGroupVolumeConnection -Array $FlashArray -VolumeName 'TEST-VOL2' -HostGroupName 'TEST-HOSTGROUP'

#
# FlashRecover Snapshots
#
New-PfaVolumeSnapshots -Array $FlashArray -Sources 'TEST-VOL1','TEST-VOL2' -Suffix 'EXAMPLE'
New-PfaVolume -Array $FlashArray -Source 'TEST-VOL1.EXAMPLE' -VolumeName 'NEW-TEST-VOL1'
New-PfaVolume -Array $FlashArray -Source 'TEST-VOL2.EXAMPLE' -VolumeName 'TEST-VOL2' –Overwrite

#
# Protection Groups
#
New-PfaProtectionGroup -Array $FlashArray -Name ‘TEST-PGROUP’
$Volumes = @()
ForEach($i in 1..10) { $Volumes += @("TEST-VOL$i") }
$Volumes
Add-PfaVolumesToProtectionGroup -Array $FlashArray -VolumesToAdd $Volumes -Name 'TEST-PGROUP'
New-PfaProtectionGroupSnapshot -Array $FlashArray -Protectiongroupname 'TEST-PGROUP' -Suffix 'EXAMPLE'
Get-PfaProtectionGroupSnapshots -Array $FlashArray -Name 'TEST-PGROUP'
Get-PfaProtectionGroupSchedule -Array $FlashArray -ProtectionGroupName 'TEST-PGROUP'
Set-PfaProtectionGroupSchedule -Array $FlashArray -SnapshotFrequencyInSeconds 21600 -GroupName 'TEST-PGROUP'
Eable-PfaSnapshotSchedule -Array $FlashArray -Name 'TEST-PGROUP'

$Volumes = @()
ForEach($i in 1..10) { $Volumes += @("TEST-VOL$i") }
$Volumes
Remove-PfaVolumesFromProtectionGroup -Array $FlashArray -VolumesToRemove $Volumes -Name 'TEST-PGROUP'

Add-PfaHostsToProtectionGroup -Array $FlashArray -Name 'TEST-PGROUP' -HostsToAdd 'TEST-HOST1'
New-PfaProtectionGroupSnapshot -Array $FlashArray -Protectiongroupname 'TEST-PGROUP'
Remove-PfaHostsFromProtectionGroup -Array $FlashArray -HostsToRemove 'TEST-HOST1' -Name 'TEST-PGROUP'

Add-PfaHostGroupsToProtectionGroup -Array $FlashArray -HostGroupsToAdd 'TEST-HOSTGROUP' -Name 'TEST-PGROUP'
New-PfaProtectionGroupSnapshot -Array $FlashArray -Protectiongroupname 'TEST-PGROUP'

#
# Monitor Metrics
#
Get-Command -Module PureStoragePowerShellSDK *Metric
Get-PfaVolumeIOMetrics -Array $FlashArray -VolumeName ‘TEST-VOL1’ –TimeRange 1h | Format-Table –AutoSize
Get-PfaVolumeIOMetrics -Array $FlashArray -VolumeName ‘TEST-VOL1’ –TimeRange 1h | Export-Csv -Path ‘C:\temp\test.csv’